def Topla(sayi1, sayi2):
    return sayi1+sayi2
toplam = Topla(3, 4)
#print(toplam)

Topla2 = lambda s1, s2 : s1+s2
toplam2 = Topla2(15, 25)
print(toplam2)
