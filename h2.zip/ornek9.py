isim = "ZaferMer.haba"
a = isim.split(".")
print(a[0][0])
