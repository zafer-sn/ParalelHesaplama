import ornek7 as orn
def cikarma(s1, s2):
    return orn.Topla(s1,s2)-(s1+s2)