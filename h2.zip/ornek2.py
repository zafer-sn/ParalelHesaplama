import ornek1

if __name__ == '__main__':
    ornek1.GorusuruzYaz()
    a = 5
    b = "selam"
    print(a)
    print(b)