"""
snake_case -> değişken tanımlarken kelimeler arasına _ ekleniyor
camelCase -> değişken tanımlarken ilk kelimenin ilk harfi küçük diğer kelimelerin ilk harfleri büyük
PascalCase -> kelimelerin tüm harfleri büyük
"""
# define -> tanımlamak
def SelamYaz():
    print("Selam")

if __name__ == '__main__':
    def GorusuruzYaz():
        print("Görüşürüz")
    SelamYaz()
    GorusuruzYaz()








