def Topla(sayi1, sayi2):
    topla = sayi1+sayi2
    return topla
deneme = Topla(5, 7)
print(deneme)
