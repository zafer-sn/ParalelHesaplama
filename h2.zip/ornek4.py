c = 6
print("Selam") if c == 5 else print("deneme")