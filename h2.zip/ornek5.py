def Topla(sayi1, sayi2):
    pass
print("Selam")

i = 1
while i < 5:
    pass