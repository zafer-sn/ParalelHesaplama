import multiprocessing
import random
from multiprocessing import Process
from threading import Thread

liste = []
a = multiprocessing.Value("i", 5)
def topla():
    global liste
    for i in range(5000):
        liste.append(random.randint(1, 100))

def topla2():
    global liste
    for i in range(5001, 10000):
        liste.append(random.randint(1, 100))

if __name__ == '__main__':
    t = Thread(target=topla)
    t2 = Thread(target=topla2)
    t.start()
    t2.start()
    t.join()
    t2.join()
    print(*liste)