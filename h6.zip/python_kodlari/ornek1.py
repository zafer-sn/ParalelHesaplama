sozluk = {"isim":"Alican", 5:"deneme", True: 2.5, "soyisim":"Selen"}
print(sozluk["isim"])
