liste1 = [1, "selam", True, 5.3]
liste2 = [2, "merhaba", False, 2.4]
liste3 = [3, "deneme", True, 5.1]
liste4 = [4, "test", False, 2.1]
liste1[0] = 25
liste2[1] = "görüşürüz"
liste3[2] = False
liste1 = liste3
liste2 = liste4
for i in liste1:
    print(i)
for i in liste2:
    print(i)
for i in liste3:
    print(i)