sayi1 = int(input("Lütfen bir sayi giriniz..:"))
if sayi1 > 75 and sayi1 < 100:
    print("AA ile geçti")
elif sayi1 > 50 and sayi1 < 75:
    print("BB ile geçti")
else:
    print("FF ile kaldı")