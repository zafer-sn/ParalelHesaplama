sayi1 = 5
sayi2 = 7
print(sayi1, sayi2)
sayi1, sayi2 = sayi2, sayi1
print(sayi1, sayi2)