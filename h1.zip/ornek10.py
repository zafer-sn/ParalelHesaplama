isim = "Zafer"
print(isim[::-1])