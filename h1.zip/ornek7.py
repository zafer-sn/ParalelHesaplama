sayi1 = 5
sayi2 = 7
isim = "Zafer"
# print("Sayi1 \n= ", sayi1, "Sayi2 =", sayi2, "İsim =",isim)
print(f"Sayı1 = {sayi1} Sayı2 = {sayi2} isim = {isim}")