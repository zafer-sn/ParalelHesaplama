sayi1 = int(input("Bir değer giriniz..:"))
if (sayi1 > 50):
    print("Geçti")
else:
    print("Kaldı")