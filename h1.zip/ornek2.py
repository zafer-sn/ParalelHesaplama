"""
Operatörler:
+ -> Toplama
- -> Çıkarma
/ -> Bölme
* -> Çarpma
% -> Mod alma
// -> Tam bölme
** -> Üs alma
"""
sayi1 = int(input("Lütfen 1. sayiyi giriniz..:"))
sayi2 = int(input("Lütfen 2. sayiyi giriniz..:"))
print(sayi1+sayi2)