i = 1
while i < 5:
    i += 1  # i = i + 1
    print(i)
