for i in range(101, ):
    print(i)