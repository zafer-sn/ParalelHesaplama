sayi1 = 5
isim = "Zafer"
sayi2 = 7.5
karmasik = 5j
giris_yapildimi = True

print(type(giris_yapildimi))
# Bu bir yorum satırıdır.
"""
Bu çok satırlı bir
yorumdur.
"""