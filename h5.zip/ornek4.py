from multiprocessing import Process
from threading import Thread


def fonk1():
    for i in range(500):
        print(f"{i} \n")

def fonk2():
    for i in range(500, 1001):
        print(f"{i} \n")

if __name__ == '__main__':
    t1 = Thread(target=fonk1) # t1 = Process(target=fonk1)
    t2 = Thread(target=fonk2) # t2 = Process(target=fonk2)
    t1.start()
    t2.start()