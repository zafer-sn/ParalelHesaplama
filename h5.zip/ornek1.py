import time
from threading import Thread


def is_yap():
    print("işe başla")
    time.sleep(1)
    print("işi bitir")


if __name__ == '__main__':
    for i in range(5):
        is_yap()