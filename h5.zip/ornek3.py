import os
import time
from multiprocessing import Process
from threading import Thread


def topla():
    a = 0
    for i in range(200000000):
        a += 1


if __name__ == '__main__':
    for i in range(os.cpu_count()):
        t1 = Process(target=topla) # t1 = Thread(target=topla)
        t1.start()


