import json
import string
from urllib.request import urlopen, Request


def karakter_sayisi_bul(url, tablo):
    cevap = urlopen(Request(url, headers={'User-Agent' : 'Chrome'}))
    cevap_txt = str(cevap.read().decode("utf-8"))
    for h in cevap_txt:
        harf = h.lower()
        if harf in tablo:
            tablo[harf] += 1

def main():
    tablo = {}
    karakter = string.ascii_lowercase
    for k in karakter:
        tablo[k] = 0

    karakter_sayisi_bul("https://www.rfc-editor.org/rfc/rfc1000.txt", tablo)
    print(json.dumps(tablo, indent=4))
main()