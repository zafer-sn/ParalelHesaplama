import math
import random
import time
from multiprocessing import Process, Queue
from threading import Thread
# global olarak icerideki_nokta_sayisi nı tanımladık ve 0 değerini atadık.
icerideki_nokta_sayisi = 0
# dışarıdan gelen toplam_nokta_sayisi parametresi ile çalışan monte_carlo fonksiyonunu yazdık
def monte_carlo(toplam_nokta_sayisi, qq):
    # burada kullanılan icerideki_nokta_sayisi değişkeninin global olduğunu belirttik
    global icerideki_nokta_sayisi
    # 0'dan toplam_nokta_sayisina(dahil değil) kadar bir döngü oluşturduk
    # Bu döngüde -1 ve 1 arasında ondalıklı olarak 2 adet değer aldık(x ve y)
    # x ve y değişkenlerinin orjine(0,0)'a olan uzaklığını(z) bulabilmek için
    # pisagor teoremi(x^2 + y^2 = z^2) kullandık.
    # Eğer z değeri 1'den küçükse çemberin içindedir.
    for i in range(toplam_nokta_sayisi):
        x = random.uniform(-1, 1)
        y = random.uniform(-1, 1)
        z = math.sqrt((x ** 2) + (y ** 2))
        if z < 1:
            icerideki_nokta_sayisi += 1
    qq.put(icerideki_nokta_sayisi)

if __name__ == '__main__':
    # thread_sayisi'nı 8 olarak belirledik, threadler adında boş bir liste oluşturduk.
    # toplam_nokta_sayisi'nı 1000000 olarak belirledik. bas_zamani'nı aldık
    thread_sayisi = 8
    threadler = []
    toplam_nokta_sayisi = 10000000
    qq = Queue()
    top = 0
    bas_zamani = time.time()
    # 8 adet thread oluşturduk ve boş listeye ekledik.
    for i in range(thread_sayisi):
        t = Process(target=monte_carlo, args=(toplam_nokta_sayisi, qq))
        threadler.append(t)
    # threadleri başlattık
    for i in threadler:
        i.start()
    # threadlerin tamamlanmasını bekledik
    for i in threadler:
        i.join()
    for i in range(8):
        top += qq.get(i)
    print(top)

    # bitis_zamani'nı aldık
    bitis_zamani = time.time()
    # pi_sayisi'nı hesaplattık.
    pi_sayisi = 4*top/(toplam_nokta_sayisi*thread_sayisi)
    # Bulunan pi değerini ve geçen süreyi yazdırdık.
    print(f"Hesaplanan değer: {pi_sayisi}, Geçen süre: {bitis_zamani-bas_zamani}")
