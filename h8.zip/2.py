import time
from threading import Thread, Lock
# harcayan ve kazanan 2 thread oluşturduk. Kazanan thread toplam para değerini 10 artırırken
# harcayan thread toplam para değerini 10 azaltıyor. Mutexler ile race conditionı engelledik.
# Python sürümlerine göre race conditionın durum değişikliği olduğu unutulmamalı; ancak Python
# 3.12 kullanılması race condition'ın her durumda önüne geçildiği anlamına gelmez!
for i in range(5):
    mutex = Lock()
    toplam_para = 100
    def harcayan(mutex):
        global toplam_para
        mutex.acquire()
        for i in range(10000000):
            toplam_para -= 10
        mutex.release()
    def kazanan(mutex):
        global toplam_para
        mutex.acquire()
        for i in range(10000000):
            toplam_para += 10
        mutex.release()

    mutex = Lock()
    t1 = Thread(target=harcayan, args=(mutex, ))
    t2 = Thread(target=kazanan, args=(mutex, ))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print(f"Kalan para: {toplam_para}")