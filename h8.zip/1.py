# Kütüphane tanımlamaları
import json
import string
import time
from multiprocessing import Lock
from threading import Thread
from urllib.request import urlopen, Request
# import numpy as np
# global değişkenlerin tanımlanması
toplam_harf_sayisi = 0
biten_thread_sayisi = 0
mutex = Lock()
# harf_sayisi_bul fonksiyonunun tanımlanması
def harf_sayisi_bul(url, harf_tablosu):
    global toplam_harf_sayisi
    global biten_thread_sayisi
    global mutex
    # url'e get istediği atılması, headers belirtilmezse hata alınabilir!
    # headers ile hangi tarayıcıdan istek atacağımızı belirttik
    cevap = urlopen(Request(url, headers={"User-Agent":"Chrome"}))
    # get isteğinin cevabını okuduk, utf-8 ile decode ettik ve stringe çevirdik
    txt = str(cevap.read().decode("utf-8"))
    # txt = txt.replace(" ", "")
    # büyük ve küçük harflerin ayrı ayrı sayılmaması için hepsini küçük harf yaptık
    txt2 = txt.lower()
    # mutex ile aynı anda 1 threadin erişimini sağladık
    mutex.acquire()
    # for ile txt deki tüm harfleri tek tek okuyoruz
    for a in txt2:
        # harf = a.lower()
        # okunan harf parametre olarak aldığımız harf_tablosu'nda varsa değerini 1 artırdık
        if a in harf_tablosu:
            harf_tablosu[a] += 1
            toplam_harf_sayisi += 1
    # biten_thread_sayisi += 1
    # threadin mutex kilidini açmasını sağladık
    mutex.release()
# ana_fonksiyon adında bir fonksiyon tanımladık
def ana_fonksiyon():
    # başlangıçta boş bir dictionary(sozluk) tanımladık
    sozluk = {}
    harfler = string.ascii_lowercase # "abcdefghijklmnopqrstuvwxyz"
    # ingilizceye göre başlangıçta her bir harften 0 tane olduğunu belirttik
    for h in harfler:
        sozluk[h] = 0
    # print(json.dumps(sozluk, indent=4))
    baslangic_zamani = time.time()
    threadler = []
    # 40 tane thread oluşturduk her birisi sitedeki 1000 ile 1040 arasına istek atacak
    for i in range(1000, 1041):
        t = Thread(target=harf_sayisi_bul, args=(f"https://www.rfc-editor.org/rfc/rfc{i}.txt", sozluk))
        threadler.append(t)
    # threadleri başlattık
    for i in threadler:
        i.start()
    # threadlerin bitmesini bekledik
    for i in threadler:
        i.join()
    bitis_zamani = time.time()
    # çıktının daha okunaklı olması için json formatında 4 boşluk ile yazdırdık
    print(json.dumps(sozluk, indent=4))
    print(f"Geçen süre: {bitis_zamani-baslangic_zamani}")
    print(f"Toplam harf sayısı: {toplam_harf_sayisi}")
ana_fonksiyon()