from threading import Thread

# join hangi thread için hangi satırda tanımlanıyorsa
# o thread bitene kadar kodun devam etmeyeceği unutulmamalı!
def fonk1():
    print("selam")
def fonk2():
    print("gorusuruz")

t1 = Thread(target=fonk1)
t2 = Thread(target=fonk2)
t1.start()
t1.join()
t2.start()
t2.join()