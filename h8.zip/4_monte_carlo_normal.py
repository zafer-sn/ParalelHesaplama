import math
import random
import time

toplam_nokta_sayisi = 8000000
icerideki_nokta_sayisi = 0
baslangic_zamani = time.time()
for i in range(toplam_nokta_sayisi):
    x = random.uniform(-1, 1)
    y = random.uniform(-1, 1)
    z = math.sqrt((x ** 2) + (y ** 2))
    if z < 1:
        icerideki_nokta_sayisi += 1

pi_sayisi = 4*icerideki_nokta_sayisi/(toplam_nokta_sayisi)
bitis_zamani = time.time()
print(f"Hesaplanan değer: {pi_sayisi}, Geçen süre: {bitis_zamani - baslangic_zamani}")
