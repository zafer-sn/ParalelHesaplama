"""
Condition variables örneği
wait -> beklemeyi sağlar
notify -> sadece ilgili condition variableın şartını tekrar kontrol eder
notify_all -> tüm condition variableların şartını tekrar kontrol eder
acquire -> ilgili alanı kilitlemeyi sağlar
release -> ilgili alandaki kilidi kaldırmayı sağlar
"""
from threading import Thread, Lock, Condition
for i in range(10):
    para = 0
    cv = Condition()
    def kazanan():
        global para, cv

        for i in range(1000000):
            cv.acquire()
            para += 10
            cv.notify_all()
            cv.release()

    def harcayan():
        global para, cv
        for i in range(500000):
            cv.acquire()
            while para < 20:
                cv.wait()
            para -= 20
            if (para < 0):
                print("Para değeri negatiftir")
            cv.release()

    t1 = Thread(target=kazanan)
    t2 = Thread(target=harcayan)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print(f"Kalan para: {para}")