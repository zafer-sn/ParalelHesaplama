"""
Join örneği:
joinlerler ilgili thread ve processlerin tamamlanmasını beklemek için kullanılır.
eğer t1 isimli bir thread oluşturulup start ile başlatıldıktan sonra direk join
kodu çağrılırsa t1 bitmeden diğer işlemler yapılmaz. Bu nedenle genelde
threadlerin tamamı start ile başlatıldıktan sonra joinleri çağrılır.
"""
import time
from threading import Thread


def fonk1():
    print("fonksiyon 1 başladı")
    time.sleep(5)
    print("fonksiyon 1 bitti")

def fonk2():
    print("fonksiyon 2 başladı")
    t1 = Thread(target=fonk1)
    t1.start()
    t1.join()
    print("fonksiyon 2 bitti")

if __name__ == '__main__':
    t2 = Thread(target=fonk2)
    t2.start()
    t2.join()
    print("selam")