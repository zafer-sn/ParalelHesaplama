liste1 = [1, 2, "selam", 5]
for e, i in enumerate(liste1):
    print(f"{e+1}, {i}")