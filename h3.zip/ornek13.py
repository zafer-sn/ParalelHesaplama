sozluk1 = {"selam":1, 5:3, "deneme":7}
"""print(sozluk1.items())
print(sozluk1.keys())
print(sozluk1.values())"""
print(sozluk1)
sozluk1["selam"] = "deneme"
print(sozluk1[7])