set1 = {1, 2, 3, 4, 5}
set2 = {3, 4, 5, 6, 7}
print(set1 | set2)
print(set1 & set2)
print(set1 - set2)