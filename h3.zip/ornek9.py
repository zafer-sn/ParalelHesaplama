liste1 = [1, 2, 3, 4, "selam", 3.2, False]
print(False in liste1)