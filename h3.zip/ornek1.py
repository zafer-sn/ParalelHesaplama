liste = [1, 2, "selam", True, 5.3]
print(*liste)