liste1 = ["selam", 1, 2, 5.4, False]
liste2 = ['dene', 5]
liste1 = liste2
liste1[-1] = "a"
liste2[-2] = 5.3
print(*liste1)
print(*liste2)