# garbage collector - çöp toplayıcı constructor - yapıcı metot
liste = list((1, 2, 3 ,5))
print(liste)