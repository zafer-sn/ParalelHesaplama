# mutable
# constructor - yapıcı metot
liste = [1, 3, "selam", False, 5.4]
liste[0] = 25
liste[-1] = "merhaba"
print(*liste)
print(type(liste))