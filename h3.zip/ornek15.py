sozluk1 = {"test":5, "deneme":{1:5, "selam":"Alican"}}
print(sozluk1["deneme"]["selam"])