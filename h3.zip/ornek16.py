sozluk1 = {"selam":1, 5:3, "test":{1:5, "deneme":"merhaba"}}
sozluk2 = {"a1":1, "a2":2}
sozluk2 = sozluk1
for i in sozluk2.keys():
    sozluk2[i] = 5