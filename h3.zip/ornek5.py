liste1 = [1, 2, 3, "selam", 5, 1]
"""liste1.append(1.3)
liste1.pop(1)"""
# liste1.insert(1, "deneme")
print(liste1.index("selam"))
print(liste1.count(1))
# print(len(liste1))