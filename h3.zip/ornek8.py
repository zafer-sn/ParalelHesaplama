#immutable
tuple1 = (1, 2, "selam", True, 5.3, 2, 2)
print(tuple1)