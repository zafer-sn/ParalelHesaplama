import json

sozluk1 = {"deneme":3, True:6, "test":"selam"}
print(json.dumps(sozluk1, indent=4))