liste1 = [i**2 for i in range(100)]
print(liste1)