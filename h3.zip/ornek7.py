liste1 = [1, 2, 3, "selam", [4.3, 5, "deneme"]]
print(liste1[4][0])