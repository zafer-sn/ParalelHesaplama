liste1 = [4, 3, -1, 6, 2, 100,-5]
"""liste1.sort()
liste1.reverse()"""
liste2 = ["selam", 5, -2]
liste1.extend(liste2)
print(liste1)