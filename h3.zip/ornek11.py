set1 = {1 ,2 ,"deneme", "test", False, 1, "deneme"}
set1.add(5)
set1.pop()
print(*set1)