import os
from multiprocessing import Process

# Parametre olarak gönderilen sayının asal olup olmadığını bulan fonksiyon
def asalmi(sayi):
    # Başlangıçta gelen her sayıyı asal kabul ediyoruz
    asal = True
    # Eğer parametre olarak gelen sayı 2 ile kendisinin 1 eksiği
    # arasındaki herhangi bir sayıya bölünüyorsa asal değerini False yapıyoruz
    for i in range(2, sayi):
        if sayi % i == 0:
            asal = False
    # asal değerini geri döndürüyoruz
    return asal
# sophie germain sayılarını hesaplamak için yazılan fonksiyon
def sophie(liste):
    # soruda 10.000 ile 100.000 arası denmiş ama çok uzun süreceği için
    # şimdilik 10.000 ile 10.100 arasını aldık
    # Bu for döngüsü 10.000 ile 10.100 arasını döner(sol dahil sağ dahil değil!)
    for i in range(10000, 10100):
        # döngüden gelen değer ve onun 2 katından 1 fazlası asal ise
        # listeye ekliyoruz
        if asalmi(i) and asalmi(2*i+1):
            liste.append(i)
    # listeyi yazdırıyoruz
    print(liste)


if __name__ == '__main__':
    # 2 adet boş liste tanımladık
    liste = []
    processler = []
    # 8 tane process oluşturuyoruz ve bunları listeye ekliyoruz
    # burada processler henüz başlatılmadı!
    for i in range(8):
        p = Process(target=(sophie), args=(liste, ))
        processler.append(p)
    # processleri başlatıyoruz.
    for i in processler:
        i.start()
    # processlerin tamamlanmasını bekliyoruz.
    for i in processler:
        i.join()