"""
Bariyer kullanarak thread senkronizasyonu örneği;
kırmızı ve mavi isminde 2 adet thread kullandık.
Bunların ikisi de wait() kısmına gelmeden bariyer kırılmaz!
Herhangi birinin bariyere gelmiş olması bariyerin kırılmasını gerektirmez!
"""
import time
from threading import Barrier, Thread

bariyer = Barrier(2)
def fonk(isim, bekleme_suresi):
    global bariyer
    for i in range(2):
        print(f"{isim} çalışıyor")
        time.sleep(bekleme_suresi)
        print(f"{isim} bariyerde bekliyor")
        bariyer.wait()
    print(f"{isim} bitti")

kirmizi = Thread(target=fonk, args=("kirmizi", 5))
mavi = Thread(target=fonk, args=("mavi", 10))
kirmizi.start()
mavi.start()
kirmizi.join()
mavi.join()
print("sonlandi")
