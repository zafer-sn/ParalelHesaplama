"""
Bariyerlerin istenilen bir zamanda terk edilebilmesi(iptal edilebilmesi)
için abort() kullanılabilir.
"""
import time
from threading import Barrier, Thread

bariyer = Barrier(2)
txt = "selam"
def fonk(isim, bekleme_suresi):
    global bariyer
    global txt
    for i in range(5):
        if i == 1:
            txt = "deneme"
        print(f"{isim} çalışıyor")
        time.sleep(bekleme_suresi)
        print(f"{isim} bariyerde bekliyor")
        bariyer.wait()

    print(f"{isim} bitti")


kirmizi = Thread(target=fonk, args=("kirmizi", 1))
mavi = Thread(target=fonk, args=("mavi", 2))
kirmizi.start()
mavi.start()
while (txt != "deneme"):
    time.sleep(1)
else:
    bariyer.abort()
kirmizi.join()
mavi.join()
print("sonlandi")
