"""
1 ile 10000 arasındaki tam kare sayıları bularak boş listeye
ekleyen kodu 2 thread kullanarak yazdık. Aynı değerlerin
eklenmesinin önüne geçmek için set(küme) kullandık.
"""
from threading import Thread
kume = set()
def fonk1():
    global kume
    for i in range(1, 10001):
        sayi = i*i
        if (sayi < 10001):
            kume.add(sayi)

t1 = Thread(target=fonk1)
t2 = Thread(target=fonk1)
t1.start()
t2.start()
t1.join()
t2.join()
print(*kume)