"""
1 ile 10000 arasındaki tam kare sayıları bularak boş listeye
ekleyen kodu 2 thread kullanarak yazdık. Aynı değerlerin
eklenmesinin önüne geçmek için gerekli kontrolü sağladık.
"""
from threading import Thread
liste = []
def fonk1():
    global liste
    for i in range(1, 10001):
        sayi = i*i
        if (sayi < 10001 and sayi not in liste):
            liste.append(sayi)

t1 = Thread(target=fonk1)
t2 = Thread(target=fonk1)
t1.start()
t2.start()
t1.join()
t2.join()
print(*liste)