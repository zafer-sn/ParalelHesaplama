# ortak bellek alanında(shared memory) çalışan processler
import ctypes
import multiprocessing
import time
from multiprocessing import Process
def listeyi_ekrana_yaz(liste):
    while True:
        print(*liste)
        time.sleep(1)
if __name__ == '__main__':
    # multiprocessing.Value
    liste = multiprocessing.Array(ctypes.c_float, [-1] * 10, lock=True)
    p1 = Process(target=listeyi_ekrana_yaz, args=(liste, ))
    p1.start()
    for i in range(10):
        time.sleep(2)
        for j in range(10):
            liste[j] = i


