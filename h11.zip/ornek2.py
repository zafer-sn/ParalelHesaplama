# processlerin queue(kuyruk) ile haberleşmesi
import multiprocessing
import time
from multiprocessing import Process
def gonderici(qq):
    while True:
        qq.put("Merhaba")
        print("Mesaj gönderildi")
        # time.sleep(1)
def alici(qq):
    while True:
        txt = qq.get()
        print(txt)
        time.sleep(1)

if __name__ == '__main__':
    qq = multiprocessing.Queue(maxsize=10)
    p1 = Process(target=gonderici, args=(qq, ))
    p2 = Process(target=alici, args=(qq, ))
    p1.start()
    p2.start()
    p1.join()
    p2.join()
