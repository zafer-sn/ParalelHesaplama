# Ornek asal sayi kodu
def asalmi(deger):
    asal = True
    for i in range(2, deger):
        if deger % i == 0:
            asal = False
    return asal

for i in range(2, 1000):
    if (asalmi(i) and asalmi(2*i +1)):
        print(i)