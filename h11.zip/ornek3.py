# ping - pong örneği
# processlerin pipe(boru) ile haberleşmesi
import multiprocessing
import time
from multiprocessing import Process


def ping(pp):
    while True:
        pp.send(["ping", time.time()])
        txt = pp.recv()
        print(txt)
        time.sleep(1)

def pong(pp):
    while True:
        txt = pp.recv()
        print(txt)
        pp.send(["pong", time.time()])
        time.sleep(1)

if __name__ == '__main__':
    pp1, pp2 = multiprocessing.Pipe()
    p1 = Process(target=ping, args=(pp1, ))
    p2 = Process(target=pong, args=(pp2, ))
    p1.start()
    p2.start()